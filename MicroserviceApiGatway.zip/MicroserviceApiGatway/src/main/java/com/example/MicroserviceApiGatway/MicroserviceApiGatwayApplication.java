package com.example.MicroserviceApiGatway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceApiGatwayApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceApiGatwayApplication.class, args);
	}

}
